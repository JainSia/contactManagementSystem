package com.yash.cmsapp.daoimpl;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;

import com.yash.cmsapp.dao.UserDAO;
import com.yash.cmsapp.model.User;
import com.yash.cmsapp.util.DSUtil;
/**
 * This class is implementation of UserDAO
 * @author saloni.jain
 *
 */
public class UserDAOImpl implements UserDAO{
	private static Logger logger=Logger.getLogger(UserDAOImpl.class);
	@Override
	public void insert(User user) {
		PreparedStatement pstmt=null;
		try {
		String sql="insert into users(name,email,address,contact,username,password) values(?,?,?,?,?,?);";
		pstmt=DSUtil.createPreparedStatement(sql);
		pstmt.setString(1, user.getName());
		pstmt.setString(2, user.getEmail());
		pstmt.setString(3, user.getAddress());
		pstmt.setString(4,user.getContact());
		pstmt.setString(5, user.getUsername());
		pstmt.setString(6, user.getPassword());
		pstmt.execute();
		} catch (SQLException e) {
			logger.error(e);
		}	
	}

	@Override
	public void delete(User user) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Integer id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(Integer id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<User> list() {
		// TODO Auto-generated method stub
		return null;
	}

}
