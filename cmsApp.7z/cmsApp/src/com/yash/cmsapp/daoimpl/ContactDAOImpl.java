package com.yash.cmsapp.daoimpl;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.yash.cmsapp.dao.ContactDAO;
import com.yash.cmsapp.model.Contact;
import com.yash.cmsapp.util.DBUtil;

public class ContactDAOImpl implements ContactDAO {

	private static Logger logger=Logger.getLogger(ContactDAOImpl.class);
	@Override
	public void insert(Contact contact) {
		try{
		String sql="insert into contacts(name,contact,email,address,user_id) values(?,?,?,?,?);";
		PreparedStatement pstmt=DBUtil.createPreparedStatement(sql);
		pstmt.setString(1, contact.getName());
		pstmt.setString(2, contact.getContact());
		pstmt.setString(3, contact.getEmail());
		pstmt.setString(4, contact.getAddress());
		pstmt.setInt(5, contact.getUserId());
		pstmt.execute();
		logger.info("Object is created...");
		}catch(SQLException ex){
			logger.error(ex);
		}
	}

	@Override
	public List<Contact> getAllContactByUserId(Integer userId) {
		Contact contact=null;
		List<Contact> temproryList=new ArrayList<Contact>();
		try{
			String sql="select * from contacts where user_id=?";
			PreparedStatement pstmt=DBUtil.createPreparedStatement(sql);
			pstmt.setInt(1, userId);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()){
				contact=new Contact();
				contact.setName(rs.getString("name"));
				contact.setAddress(rs.getString("address"));
				contact.setEmail(rs.getString("email"));
				contact.setContact(rs.getString("contact"));
				contact.setId(rs.getInt("id"));
				temproryList.add(contact);
			}
		}catch(SQLException ex){
			logger.error(ex);
		}
		
		return temproryList;
	}

	@Override
	public void delete(Integer id) {
		try{
			String sql="delete from contacts where id=?";
			DBUtil.createPreparedStatement(sql);
			PreparedStatement pstmt=DBUtil.createPreparedStatement(sql);
			pstmt.setInt(1, id);
			pstmt.execute();
			
		}catch(SQLException ex){
			logger.error(ex);
		}
		
	}

	@Override
	public void update(Contact contact) {
		String sql="UPDATE contacts SET name=?,contact=?,email=?,address=? WHERE id=?;";
		PreparedStatement pstmt;
		try{
			pstmt=DBUtil.createPreparedStatement(sql);
			pstmt.setString(1, contact.getName());
			pstmt.setString(2, contact.getContact());
			pstmt.setString(3, contact.getEmail());
			pstmt.setString(4, contact.getAddress());
			pstmt.setInt(5, contact.getId());
			pstmt.execute();			
		}catch(SQLException ex){
			logger.error(ex);
		}
		
	}

	@Override
	public Contact getContactById(Integer id) {
		Contact contact=null;
		try{
			String sql="select * from contacts where id=?";
			PreparedStatement pstmt=DBUtil.createPreparedStatement(sql);
			pstmt.setInt(1, id);
			ResultSet rs=pstmt.executeQuery();
				if(rs.next()){
				contact=new Contact();
				contact.setId(rs.getInt("id"));
				contact.setName(rs.getString("name"));
				contact.setAddress(rs.getString("address"));
				contact.setEmail(rs.getString("email"));
				contact.setContact(rs.getString("contact"));
				contact.setUserId(rs.getInt("user_id"));
			}
		}catch(SQLException ex){
			logger.error(ex);
		}
		
		return contact;
	}

}
