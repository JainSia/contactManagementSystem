package com.yash.cmsapp.logger;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class CMSLogger 
{
	public static final Logger log=Logger.getLogger(CMSLogger.class);
	public static final String PROPERTIES_FILE="src/resources/log4j.properties";


	public static Logger getLogger()
	{
		Properties properties=new Properties();
		try
	    {
	      // load our log4j properties / configuration file
	      properties.load(new FileInputStream(PROPERTIES_FILE));
	      PropertyConfigurator.configure(properties);
	      log.info("Logging initialized.");
	    }
	    catch(IOException e)
	    {
	      throw new RuntimeException("Unable to load logging property " + PROPERTIES_FILE);
	    }
		return log;
	}

}
