package com.yash.cmsapp.model;
/**
 * This class will work a model object, it's work is to travel data from one layer
 * to other layer.
 * @author saloni.jain
 *
 */
public class User extends Person {
	/**
	 * id of person
	 */
	private Integer id;
	/**
	 * status of person 
	 */
	private Integer status;
	/**
	 * role of person
	 */
	private Integer role;
	/**
	 * username of person
	 */
	private String username;
	/**
	 * password of person
	 */
	private String password;
	/**
	 * this method will return the id
	 * @return
	 */
	public Integer getId() {
		return id;
	}
	/**
	 * this method will set the id
	 * @param id
	 */

	public void setId(Integer id) {
		this.id = id;
	}
	/**
	 * this method will return the status
	 * @return
	 */
	public Integer getStatus() {
		return status;
	}
	/**
	 * this method will set the status
	 * @param status
	 */
	public void setStatus(Integer status) {
		this.status = status;
	}
	/**
	 * this method will return the role
	 * @return
	 */
	public Integer getRole() {
		return role;
	}
	/**
	 * this method will set the role
	 * @param role
	 */
	public void setRole(Integer role) {
		this.role = role;
	}
	/**
	 * this method will return the username
	 * @return
	 */
	public String getUsername() {
		return username;
	}
	/**
	 * this method will set the username
	 * @param username
	 */
	public void setUsername(String username) {
		this.username = username;
	}
	/**
	 * this method will return the password
	 * @return
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * this method will set the password
	 * @param password
	 */

	public void setPassword(String password) {
		this.password = password;
	}
	

}
