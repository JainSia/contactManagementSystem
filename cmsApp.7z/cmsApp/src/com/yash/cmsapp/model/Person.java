package com.yash.cmsapp.model;
/**
 * This class will not be used as data traveller, this will work as a shared resourses
 * that will provide the commomn attribute to its sub classes
 * @author saloni.jain
 *
 */
public class Person {
	/**
	 * id of a user
	 */
	private Integer id;
	/**
	 * name of user
	 */
	private String name;
	/**
	 * contact of a user
	 */
	private String contact;
	/**
	 * address of a user
	 */
	private String address;
	/**
	 * email of a user
	 */
	private String email;
	/**
	 * this method will return id
	 * @return
	 */
	public Integer getId() {
		return id;
	}
	/**
	 * this method will set the id
	 */

	public void setId(Integer id) {
		this.id = id;
	}
	/**
	 * this method will return the name of user
	 * @return
	 */
	public String getName() {
		return name;
	}
	/**
	 * this method will set the name
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * this method will return the contact
	 * @return
	 */
	public String getContact() {
		return contact;
	}
	/**
	 * this method will set the contact
	 * @param contact
	 */
	public void setContact(String contact) {
		this.contact = contact;
	}
	/**
	 * this method will return the address
	 * @return
	 */
	public String getAddress() {
		return address;
	}
	/**
	 * this method will set the address
	 * @param address
	 */
	public void setAddress(String address) {
		this.address = address;
	}
	/**
	 * this method will return the email
	 * @return
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * this method will set the email
	 * @param email
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	
	
}
