package com.yash.cmsapp.model;

public class Contact extends Person{
	/**
	 * id of user this will work as foreign key for contact
	 */
	private Integer userId;

	/**
	 *
	 * this method will return the id
	 * @return
	 */
	public Integer getUserId() {
		return userId;
	}
	/**
	 * this method will set the id 
	 * @param id
	 */
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
}
