package com.yash.cmsapp.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.yash.cmsapp.model.User;
import com.yash.cmsapp.service.UserService;
import com.yash.cmsapp.serviceimpl.UserServiceImpl;


@WebServlet("/UserLoginController")
public class UserLoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private static UserService userService=null;
    public UserLoginController() {
        userService=new UserServiceImpl();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		User user=userService.userAuthentication(username, password);
		if(user!=null){
		HttpSession session=request.getSession(true);
		session.setAttribute("userId", user.getId());
		session.setAttribute("user", user);
		session.setAttribute("username", username);
		response.sendRedirect("./guest.jsp?msg=Registration Successfull!!!");
		}
		else{
			response.sendRedirect("./index.jsp?err=Username/password Invalid");
		}
		}

}
