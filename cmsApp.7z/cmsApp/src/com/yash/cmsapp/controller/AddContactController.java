package com.yash.cmsapp.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.jasper.tagplugins.jstl.core.ForEach;

import com.yash.cmsapp.model.Contact;
import com.yash.cmsapp.service.ContactService;
import com.yash.cmsapp.serviceimpl.ContactServiceImpl;


@WebServlet("/AddContactController")
public class AddContactController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       ContactService contactService=null;
       
       
    
    public AddContactController() {
       contactService=new ContactServiceImpl();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Contact contact=new Contact();
		List<Contact> contactsList;
		contact.setName(request.getParameter("name"));
		contact.setContact(request.getParameter("contact"));
		contact.setAddress(request.getParameter("address"));
		contact.setEmail(request.getParameter("email"));
		Integer userId=(Integer)request.getSession().getAttribute("userId");
		System.out.println(request.getParameter("id"));
		if(request.getParameter("id")!=""){
			contact.setId(Integer.parseInt(request.getParameter("id")));
			contact.setUserId(userId);
			contactService.update(contact);
			getServletContext().getRequestDispatcher("/PrepareContactList?msg=Contact updated successfully..!!!").forward(request, response);
		}
		else{
		contact.setUserId(userId);
		contactService.insert(contact);
		contactsList=contactService.getAllContactByUserId(userId);
		request.setAttribute("contacts", contactsList);
		getServletContext().getRequestDispatcher("/list_contact.jsp?msg=Contact added successfully..!!!").forward(request, response);
		}
	}
@Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	doGet(req, resp);
}
	
}
