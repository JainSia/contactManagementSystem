package com.yash.cmsapp.serviceimpl;

import java.util.List;

import com.yash.cmsapp.dao.ContactDAO;
import com.yash.cmsapp.daoimpl.ContactDAOImpl;
import com.yash.cmsapp.model.Contact;
import com.yash.cmsapp.service.ContactService;

public class ContactServiceImpl implements ContactService {
	ContactDAO contactDAO=null; 
	public ContactServiceImpl() {
		contactDAO=new ContactDAOImpl();
	}
	@Override
	public void insert(Contact contact) {
		contactDAO.insert(contact);

	}
	
	@Override
	public List<Contact> getAllContactByUserId(Integer userId) {
		List<Contact> contactList=contactDAO.getAllContactByUserId(userId);
		return contactList;
	}
	@Override
	public void delete(Integer id) {
		contactDAO.delete(id);
		
	}
	@Override
	public void update(Contact contact) {
		contactDAO.update(contact);
		
	}
	@Override
	public Contact getContactById(Integer id) {
		Contact contact=contactDAO.getContactById(id);
		return contact;
	}

}
