package com.yash.cmsapp.serviceimpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.yash.cmsapp.dao.UserDAO;
import com.yash.cmsapp.daoimpl.UserDAOImpl;
import com.yash.cmsapp.model.User;
import com.yash.cmsapp.service.UserService;
import com.yash.cmsapp.util.DBUtil;

public class UserServiceImpl implements UserService{

	private UserDAO userDAO=null;
	private static Logger logger=Logger.getLogger(UserServiceImpl.class);
	public UserServiceImpl() {
		userDAO=new UserDAOImpl();
		
	}
	@Override
	public void registerUser(User user) {
		userDAO.insert(user);
		
	}

	@Override
	public User userAuthentication(String username, String password) {
		User user = null;
		String sql="SELECT * FROM users WHERE username=? && password=?;";
		try{
		PreparedStatement preparedStatement=DBUtil.createPreparedStatement(sql);
		preparedStatement.setString(1, username);
		preparedStatement.setString(2, password);
		ResultSet rs=preparedStatement.executeQuery();
		if(rs.next()){
			user=new User();
			user.setName(rs.getString("name"));
			user.setContact(rs.getString("contact"));
			user.setAddress(rs.getString("address"));
			user.setStatus(rs.getInt("status"));
			user.setRole(rs.getInt("role"));
			user.setEmail(rs.getString("email"));
			user.setId(rs.getInt("id"));
		}
		} catch (SQLException e) {
			logger.error(e);
		}
		return user;
	}

}
