package com.yash.cmsapp.service;

import com.yash.cmsapp.model.User;
/**
 * This will perform all service related task
 * @author saloni.jain
 *
 */
public interface UserService {
	/**
	 * this will register the user
	 * @param user object
	 */
	public void registerUser(User user);
	/**
	 * this will check the authenticity of user
	 * @param username
	 * @param password
	 * @return
	 */
	public User userAuthentication(String username, String password);
}
