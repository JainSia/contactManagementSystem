package com.yash.cmsapp.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

public class DSUtil {
	private static Logger logger=Logger.getLogger(DSUtil.class);
	private static PreparedStatement preparedStatement=null;
	private static Context context=null;
	private static Connection connection=null;
	private static DataSource dataSource;
	
	static{
		try {
			context=new InitialContext();
			dataSource=(DataSource)context.lookup("java:/comp/env/jdbc/cmsappdb");
			logger.info("!! Connection Retrieved !! ");
		} catch (NamingException e) {
			logger.error("Error in static block : "+e);
		}

	}
	
	private static Connection getDataSourceConnection(){
		try {
			connection=dataSource.getConnection();
			logger.info("!! Connection created !!");
		} catch (SQLException e) {
			logger.info("Error in connection : "+e);
		}
		return connection;
	}
	
	public static PreparedStatement createPreparedStatement(String sql){
		getDataSourceConnection();
		try {
			preparedStatement=connection.prepareStatement(sql);
			logger.info("!!! Statement created...!!!");
		} catch (SQLException e) {
			logger.info("Error in preparing statement object : "+e);
		}
		return preparedStatement;
	} 
	
}
