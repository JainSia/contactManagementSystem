package com.yash.cmsapp.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;


/**
 * This class will perform operation-related to database like connection, disconnection, 
 * providing the preparedStatement object, resultSet object.
 * This class will be responsible to have transaction complete operation like 
 * closing the connection prepared statement objects etc.  
 * @author saloni.jain
 *
 */
public class DBUtil {
	private static Logger logger=Logger.getLogger(DBUtil.class);
	private static String driverName="com.mysql.jdbc.Driver";
	private static String url="jdbc:mysql://localhost/cmsappdb";
	private static String username="root";
	private static String password="root";
	private static PreparedStatement preparedStatement=null;
	private static Connection conn=null;
	
	static{
		try {
			Class.forName(driverName);
		} catch (ClassNotFoundException e) {
			logger.error(e);
		}
	}
	/**
	 * This method will return connection Object.
	 * @return
	 */
	private static Connection connect(){
		try {
			
			conn=DriverManager.getConnection(url,username,password);
		} catch (SQLException e) {
			logger.error(e);
		}
		return conn;
	}
	/**
	 * This method will return prepared statement object based on sql provided this
	 * will have a call for connection because you need a transaction that you will require
	 * at the time of  connection
	 * @param sql
	 * @return
	 */
	public static PreparedStatement createPreparedStatement(String sql){
		connect();
		try {
			preparedStatement=conn.prepareStatement(sql);
		} catch (SQLException e) {
			logger.error(e);
		}
		return preparedStatement;
	}
	/**
	 * This method will close the preparedStatement.
	 */
	public static void closePreparedStatement(){
		
		try {
			preparedStatement.close();
		} catch (SQLException e) {
			logger.error(e);
		}
	}
	/**
	 * This method will close the connection.
	 */
	public static void closeConnection(){
		
		try {
			conn.close();
		} catch (SQLException e) {
			logger.error(e);
		}
	}
	
	
}


