package com.yash.cmsapp.dao;
import java.util.List;

import com.yash.cmsapp.model.Contact;

public interface ContactDAO {
	
	public void insert(Contact contact);
	public List<Contact> getAllContactByUserId(Integer userId);
	public void delete(Integer id);
	public void update(Contact contact);
	public Contact getContactById(Integer id);
}
