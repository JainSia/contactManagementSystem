package com.yash.cmsapp.dao;

import java.util.List;

import com.yash.cmsapp.model.User;
/**
 * this interface will perform the operation related to user.
 * @author saloni.jain
 *
 */
public interface UserDAO {

	/**
	 * this method will add the user object in database
	 * @param user object
	 */
	public void insert(User user);
	/**
	 * this method will delete the user object from database
	 * @param user object
	 */
	public void delete(User user);
	/**
	 * this method will delete the user object from database based on user id
	 * @param id
	 */
	public void delete(Integer id);
	/**
	 * this method will update the user object in database based on user id
	 * @param id
	 */
	public void update(Integer id);
	/**
	 * this method will return list of users 
	 * @return
	 */
	public List<User> list();
}
