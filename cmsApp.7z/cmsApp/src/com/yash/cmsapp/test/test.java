package com.yash.cmsapp.test;

import com.yash.cmsapp.dao.UserDAO;
import com.yash.cmsapp.daoimpl.UserDAOImpl;
import com.yash.cmsapp.model.User;
import com.yash.cmsapp.service.UserService;
import com.yash.cmsapp.serviceimpl.UserServiceImpl;
import com.yash.cmsapp.util.DSUtil;


public class test {
	public static void main(String[] args) {
		String sql="insert into users(name,contact,username,password) values(?,?,?,?);";
		DSUtil.createPreparedStatement(sql);
				
		User user=new User();
		user.setName("shreya");
		user.setContact("7047276010");
		user.setEmail("s@gmail.com");
		user.setAddress("Ujjain");
		user.setUsername("shreya");
		user.setPassword("sakshi123");
		UserService userService=new UserServiceImpl();
		userService.registerUser(user);

	}
	
	
}
